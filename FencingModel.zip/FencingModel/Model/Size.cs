﻿namespace FencingGame.Model
{
    /// <summary>
    /// Játék mérete
    /// </summary>
    public enum Size { Small = 6, Medium = 8, Large = 10 }
}
