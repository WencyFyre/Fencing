﻿namespace FencingGame.Persistence
{
    /// <summary>
    /// Mező típusok
    /// </summary>
    public enum FieldType { NoPlayer, BluePlayer, RedPlayer, RedPlayerFenced, BluePlayerFenced, Wall }
}
