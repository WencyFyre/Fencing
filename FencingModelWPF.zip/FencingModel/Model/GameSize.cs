﻿namespace FencingGame.Persistence
{
    /// <summary>
    /// Játék mérete
    /// </summary>
    public enum GameSize { Small = 6, Medium = 8, Large = 10 }
}
